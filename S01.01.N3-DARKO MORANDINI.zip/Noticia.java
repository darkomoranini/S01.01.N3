
public abstract class Noticia implements Puntuacion{

	protected String titular;
	protected String texto;
	protected int puntos;
	protected int precio;
	
	public Noticia(String titular) {
		this.titular = titular;
		puntos = 0;
		precio = 0;
		texto=null;
	}
	public String getTitular() {
		return titular;
	}
	public void setTitular(String titular) {
		this.titular = titular;
	}
	public String getTexto() {
		return texto;
	}
	public void setTexto(String texto) {
		this.texto = texto;
	}
	public int getPuntos() {
		return puntos;
	}
	public int getPrecio() {
		return precio;
	}
	public void setPrecio(int precio) {
		this.precio = precio;
	}
	
	public int calcularPrecioNoticia() {		
		precio = 0;
		return precio;
		
	}
}
