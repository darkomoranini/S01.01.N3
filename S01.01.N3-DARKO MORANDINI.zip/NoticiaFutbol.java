
public class NoticiaFutbol extends Noticia{

	private String competicion;
	private String club;
	private String jugador;
	
	public NoticiaFutbol(String titular, String competicion, String club, String jugador) {
		super(titular);
		this.competicion=competicion;
		this.club=club;
		this.jugador=jugador;
	}

	public String getCompeticion() {
		return competicion;
	}

	public void setCompeticion(String competicion) {
		this.competicion = competicion;
	}

	public String getClub() {
		return club;
	}

	public void setClub(String club) {
		this.club = club;
	}

	public String getJugador() {
		return jugador;
	}

	public void setJugador(String jugador) {
		this.jugador = jugador;
	}	
	
	@Override
	public int calcularPrecioNoticia() {
		int precio = 300;
		if(competicion=="champions"){
			precio+=100;
		}
		if(club=="barsa"||club=="madrid"){
			precio+=100;	
		}
		if(jugador=="benzema"||jugador=="ferran"){
			precio+=100;		
		}	
		return precio;
	}

	@Override
	public int calculaPuntuacion() {
		int puntuacion = 5;
		if(competicion=="champions"){
			puntuacion+=3;
		}
		if(competicion=="liga"){
			puntuacion+=2;
		}
		if(club=="barsa"||club=="madrid"){
			puntuacion+=1;	
		}
		if(jugador=="benzema"||jugador=="ferran"){
			puntuacion+=1;		
		}	
		return puntuacion;
	}
}
