
public class NoticiaBaloncesto extends Noticia{

	private String competicion;
	private String club;
	
	public NoticiaBaloncesto(String titular, String competicion, String club) {
		super(titular);
		this.competicion=competicion;
		this.club=club;
	}

	public String getCompeticion() {
		return competicion;
	}

	public void setCompeticion(String competicion) {
		this.competicion = competicion;
	}

	public String getClub() {
		return club;
	}

	public void setClub(String club) {
		this.club = club;
	}

	@Override
	public int calcularPrecioNoticia() {
		int precio = 250;
		if(competicion=="euroliga"){
			precio+=75;
		}
		if(club=="barsa"||club=="madrid"){
			precio+=75;	
		}	
		return precio;
	}
	
	@Override
	public int calculaPuntuacion() {
		int puntuacion = 4;
		if(competicion=="euroliga"){
			puntuacion+=3;
		}
		if(competicion=="acb"){
			puntuacion+=2;
		}
		if(club=="barsa"||club=="madrid"){
			puntuacion+=1;	
		}	
		return puntuacion;
	}
	
}
