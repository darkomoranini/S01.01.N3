import java.util.*;

public class App {

	public static void main(String[] args) {
	
		ArrayList<Redactor>listaRedactores = new ArrayList<Redactor>();
		int opcion=1;
		while(opcion!=0) {	
			
			try {			
				opcion=Teclado.leerInt("0.-SALIR "
					+ "1.- INTRODUCIR REDACTOR "
					+ "2.- ELIMINAR REDACTOR "
					+ "3.- INTRODUCIR NOTICIA "
					+ "4.- ELIMINAR NOTICIA "
					+ "5.- MOSTAR NOTICIAS "
					+ "6.- CALCULAR PUNTUACION "
					+ "7.- CALCULAR PRECIO ");
		
					switch(opcion) {
		
					case 0:
						System.exit(0);							
						break;
					
					case 1:
						introducirRedactor(Teclado.leerString("nombre"), Teclado.leerString("dni"), listaRedactores);
						System.out.println("redactor introducido");
						break;
					
					case 2:
						try {
						eliminarRedactor(Teclado.leerString("dni"), listaRedactores);
						System.out.println("redactor eliminado");
						}catch(ArrayIndexOutOfBoundsException i){
							System.out.println("redactor no encontrado");
						}catch(ListaVaciaException e) {
							System.out.println("lista vacia");
						}
						break;
						
					case 3:
						opcion=Teclado.leerInt("0.-SALIR "
								+ "1.- FUTBOL "
								+ "2.- BALONCESTO "
								+ "3.- TENIS "
								+ "4.- F1 "
								+ "5.- MOTOCICLISMO ");
							
								switch(opcion) {
								
								case 1:
									NoticiaFutbol noticiaFut = new NoticiaFutbol(Teclado.leerString("titular"), Teclado.leerString("competicion"), Teclado.leerString("club"), Teclado.leerString("jugador"));
									try {
									listaRedactores.get(buscarRedactor(Teclado.leerString("dni"), listaRedactores)).getListaNoticias().add(noticiaFut);
									System.out.println("noticiaFutbol introducida");
									}catch(ArrayIndexOutOfBoundsException i){
										System.out.println("redactor no encontrado");
									}catch(ListaVaciaException e) {
										System.out.println("lista vacia");
									}
									break;
								
								case 2:
									NoticiaBaloncesto noticiaBal = new NoticiaBaloncesto(Teclado.leerString("titular"), Teclado.leerString("competicion"), Teclado.leerString("club"));
									try {
									listaRedactores.get(buscarRedactor(Teclado.leerString("dni"), listaRedactores)).getListaNoticias().add(noticiaBal);
									System.out.println("noticiaBaloncesto introducida");
									}catch(ArrayIndexOutOfBoundsException i){
										System.out.println("redactor no encontrado");
									}catch(ListaVaciaException e) {
										System.out.println("lista vacia");
									}
									break;
									
								case 3:
									NoticiasTenis noticiaTen = new NoticiasTenis(Teclado.leerString("titular"), Teclado.leerString("jugador"));
									try {
									listaRedactores.get(buscarRedactor(Teclado.leerString("dni"), listaRedactores)).getListaNoticias().add(noticiaTen);
									System.out.println("noticiaTenis introducida");
									}catch(ArrayIndexOutOfBoundsException i){
										System.out.println("redactor no encontrado");
									}catch(ListaVaciaException e) {
										System.out.println("lista vacia");
									}
									break;
									
								case 4 :
									NoticiasF1 noticiaF1 = new NoticiasF1(Teclado.leerString("titular"), Teclado.leerString("escuderia"));
									try {
									listaRedactores.get(buscarRedactor(Teclado.leerString("dni"), listaRedactores)).getListaNoticias().add(noticiaF1);
									System.out.println("noticiaF1 introducida");
									}catch(ArrayIndexOutOfBoundsException i){
										System.out.println("redactor no encontrado");
									}catch(ListaVaciaException e) {
										System.out.println("lista vacia");
									}
									break;
								
								case 5:
									NoticiaMotociclismo noticiaMoto = new NoticiaMotociclismo(Teclado.leerString("titular"), Teclado.leerString("equipo"));
									try {
									listaRedactores.get(buscarRedactor(Teclado.leerString("dni"), listaRedactores)).getListaNoticias().add(noticiaMoto);	
									System.out.println("noticiaMotociclismo introducida");
									}catch(ArrayIndexOutOfBoundsException i){
										System.out.println("redactor no encontrado");
									}catch(ListaVaciaException e) {
										System.out.println("lista vacia");
									}
									break;								
								}								
								break;
												
					case 4:
						try {
						eliminarNoticia(Teclado.leerString("dni"), Teclado.leerString("titular"), listaRedactores);
						System.out.println("eliminado correctamente");
						}catch(ArrayIndexOutOfBoundsException i){
							System.out.println("noticia no encontrado");
						}catch(ListaVaciaException e) {
							System.out.println("lista vacia");
						}
						break;
							
					case 5:
						try {
						mostrarNoticias(Teclado.leerString("dni"), listaRedactores);
						}catch(ArrayIndexOutOfBoundsException i){
							System.out.println("redactor no encontrado");
						}catch(ListaVaciaException e) {
							System.out.println("lista vacia");
						}
						break;								
					
					case 6:
						try {
						int puntuacion = calculaPuntuacionTotal(Teclado.leerString("dni"), listaRedactores);
						System.out.println(puntuacion);
						}catch(ArrayIndexOutOfBoundsException i){
							System.out.println("redactor no encontrado");
						}catch(ListaVaciaException e) {
							System.out.println("lista vacia");
						}
						break;
						
					case 7:
						try {
						int precioTotal = calculaPrecioTotal(Teclado.leerString("dni"), listaRedactores);
						System.out.println(precioTotal);
						}catch(ArrayIndexOutOfBoundsException i){
							System.out.println("redactor no encontrado");
						}catch(ListaVaciaException e) {
							System.out.println("lista vacia");
						}
						break;
					 }
       
			} 
			catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Error: El redactor no se encontró o el índice está fuera de rango.");
        }
    }
}

	public static void introducirRedactor(String nombre, String dni, ArrayList<Redactor>listaRedactores) {
		Redactor redactor = new Redactor(nombre, dni);
		listaRedactores.add(redactor);	
	}
	
	public static void eliminarRedactor(String dni, ArrayList<Redactor>listaRedactores) throws ListaVaciaException, ArrayIndexOutOfBoundsException {
		int index = buscarRedactor(dni, listaRedactores);
        if (index != -1) {
            listaRedactores.remove(index);
        } else {
            throw new ArrayIndexOutOfBoundsException();
        }
    }
	
	public static void eliminarNoticia(String dni, String titular, ArrayList<Redactor>listaRedactores) throws ListaVaciaException, ArrayIndexOutOfBoundsException {
		 int redactorIndex = buscarRedactor(dni, listaRedactores);
	        if (redactorIndex != -1) {
	            int noticiaIndex = buscarNoticia(dni, titular, listaRedactores);
	           
	            if (noticiaIndex != -1) {
	                listaRedactores.get(redactorIndex).getListaNoticias().remove(noticiaIndex);
	            } else {
	                throw new ArrayIndexOutOfBoundsException();
	            }
	        } else {
	            throw new ArrayIndexOutOfBoundsException();
	        }
	    }
	
	public static int buscarRedactor(String dni, ArrayList<Redactor>listaRedactores) throws ListaVaciaException, ArrayIndexOutOfBoundsException {
		 if (listaRedactores.isEmpty()) {
	            throw new ListaVaciaException();
	        }
	        for (int i = 0; i < listaRedactores.size(); i++) {
	            
	        	if (dni.equalsIgnoreCase(listaRedactores.get(i).getDni())) {
	               
	            	return i;
	            }
	        }

	        throw new ArrayIndexOutOfBoundsException();
	    }
	
	public static void mostrarNoticias(String dni, ArrayList<Redactor>listaRedactores) throws ListaVaciaException, ArrayIndexOutOfBoundsException {
		int redactorIndex = buscarRedactor(dni, listaRedactores);
       
		if (redactorIndex != -1) {
            String noticias = listaRedactores.get(redactorIndex).getListaNoticias().toString();
            System.out.println(noticias);
        } else {
            throw new ArrayIndexOutOfBoundsException();
        }
    }
	
	public static int buscarNoticia(String dni, String titular, ArrayList<Redactor>listaRedactores) throws ListaVaciaException, ArrayIndexOutOfBoundsException {
		 if (listaRedactores.get(buscarRedactor(dni, listaRedactores)).getListaNoticias().isEmpty()) {
	            throw new ArrayIndexOutOfBoundsException();
	        }

	        for (int i = 0; i < listaRedactores.get(buscarRedactor(dni, listaRedactores)).getListaNoticias().size(); i++) {
	            if (titular.equalsIgnoreCase(listaRedactores.get(buscarRedactor(dni, listaRedactores)).getListaNoticias().get(i).getTitular())) {
	                return i;
	            }
	        }
	        throw new ArrayIndexOutOfBoundsException();
	}
	
	public static int calculaPuntuacionTotal(String dni, ArrayList<Redactor>listaRedactores) throws ListaVaciaException, ArrayIndexOutOfBoundsException {
		 int puntuacionTotal = 0;
	        int redactorIndex = buscarRedactor(dni, listaRedactores);
	       
	        if (redactorIndex != -1) {
	            ArrayList<Noticia> listaNoticias = listaRedactores.get(redactorIndex).getListaNoticias();
	           
	            for (int i = 0; i < listaNoticias.size(); i++) {
	                puntuacionTotal += listaNoticias.get(i).calculaPuntuacion();
	            }
	            return puntuacionTotal;
	        } else {
	            throw new ArrayIndexOutOfBoundsException();
	        }
	    }
	
	public static int calculaPrecioTotal(String dni, ArrayList<Redactor>listaRedactores) throws ListaVaciaException, ArrayIndexOutOfBoundsException {		
		int precioTotal = 0;
        int redactorIndex = buscarRedactor(dni, listaRedactores);
       
        if (redactorIndex != -1) {
            ArrayList<Noticia> listaNoticias = listaRedactores.get(redactorIndex).getListaNoticias();
           
            for (int i = 0; i < listaNoticias.size(); i++) {
                precioTotal += listaNoticias.get(i).calcularPrecioNoticia();
            }
            return precioTotal;
        } else {
            throw new ArrayIndexOutOfBoundsException();
        }
    }
}
