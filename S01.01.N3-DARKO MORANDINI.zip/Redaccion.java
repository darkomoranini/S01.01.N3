import java.util.ArrayList;

public abstract class Redaccion {

	private ArrayList<Noticia>listaNoticias;
	private ArrayList<Redactor>listaRedactores;
	
	public Redaccion() {
		listaNoticias= new ArrayList<Noticia>();
		listaRedactores = new ArrayList<Redactor>();
	}

	public ArrayList<Noticia> getListaNoticias() {
		return listaNoticias;
	}

	public void setListaNoticias(ArrayList<Noticia> listaNoticias) {
		this.listaNoticias = listaNoticias;
	}

	public ArrayList<Redactor> getListaRedactores() {
		return listaRedactores;
	}

	public void setListaRedactores(ArrayList<Redactor> listaRedactores) {
		this.listaRedactores = listaRedactores;
	}
	
	
	
}
