import java.util.ArrayList;

public class NoticiasTenis extends Noticia{

	String jugador;
	ArrayList<String>tenistas;
	
	public NoticiasTenis(String titular, String jugador) {
		super(titular);
		this.jugador=jugador;
		tenistas=new ArrayList<String>();
	}
	public ArrayList<String> getTenistas() {
		return tenistas;
	}

	public void setTenistas(ArrayList<String> tenistas) {
		this.tenistas = tenistas;
	}

	@Override
	public int calcularPrecioNoticia() {
		int precio = 150;

		if(jugador=="federer"||jugador=="nadal"||jugador=="djokovic"){
			precio+=100;		
		}	
		return precio;
	}
	
	@Override
	public int calculaPuntuacion() {
		int puntuacion = 4;

		if(jugador=="federer"||jugador=="nadal"||jugador=="djokovic"){
			puntuacion+=3;		
		}	
		return puntuacion;
	}
}
