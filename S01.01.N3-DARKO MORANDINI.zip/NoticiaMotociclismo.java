
public class NoticiaMotociclismo extends Noticia{

	private String equipo;
	
	public NoticiaMotociclismo(String titular, String equipo) {
		super(titular);
		this.equipo=equipo;
		
	}
	
	@Override
	public int calcularPrecioNoticia() {
		int precio = 100;
		if(equipo=="honda"||equipo=="yamaha"){
			precio+=50;
		}	
		return precio;
	}
	@Override
	public int calculaPuntuacion() {
		int puntuacion = 3;
		if(equipo=="honda"||equipo=="yamaha"){
			puntuacion+=3;
		}	
		return puntuacion;
	}
	
}
