
@FunctionalInterface
public interface Puntuacion {

	public int calculaPuntuacion();
}
