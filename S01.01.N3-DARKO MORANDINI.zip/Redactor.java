import java.util.ArrayList;

public class Redactor {

	private String nombre;
	private final String dni;
	private static int sueldo = 1500;
	private ArrayList<Noticia>listaNoticias;
	
	public Redactor(String nombre, String dni) {
		this.nombre = nombre;
		this.dni = dni;
		listaNoticias = new ArrayList<Noticia>();
	}

	public ArrayList<Noticia> getListaNoticias() {
		return listaNoticias;
	}

	public void setListaNoticias(ArrayList<Noticia> listaNoticias) {
		this.listaNoticias = listaNoticias;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDni() {
		return dni;
	}

	public int getSueldo() {
		return sueldo;
	}
}
