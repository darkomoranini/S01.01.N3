
public class NoticiasF1 extends Noticia{

	private String escuderia;
	
	public NoticiasF1(String titular, String escuderia) {
		super(titular);
		this.escuderia=	escuderia;
	}

	public String getEscuderia() {
		return escuderia;
	}

	public void setEscuderia(String escuderia) {
		this.escuderia = escuderia;
	}

	@Override
	public int calcularPrecioNoticia() {
		int precio = 100;
		if(escuderia=="mercedes"||escuderia=="ferrari"){
			precio+=50;
		}
		return precio;
	}
	
	@Override
	public int calculaPuntuacion() {
		int puntuacion = 0;
		if(escuderia=="ferrari"){
			puntuacion+=2;
		}
		if(escuderia=="mercedes"){
			puntuacion+=2;
		}
		return puntuacion;
	}
	
	
}
